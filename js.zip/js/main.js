$(document).ready(function(){

  // For brand slider 


    $('.owl-carousel').owlCarousel({
        responsive:{
            0:{
                items:2
            },
            600:{
                items:4
            },
            1000:{
                items:6
            }
        },
        loop:true,
        margin:10,
        autoplay:true,
        autoplayTimeout:1000,
        autoplayHoverPause:true
    });


    // For mobile menubar

    $(function(){
		$('#menu').slicknav({
            label: '',
        });
	});


    
});




